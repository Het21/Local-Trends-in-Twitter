function getData(lat,longi) {
	path = "woeidapi.php?lat="+lat+"&long="+longi;

	var input = {
	    method : 'get',
	    returnedContentType : 'json',
	    path : path
	};


	return WL.Server.invokeHttp(input);
}